package org.txlcn.demo.servicea;

import org.apache.ibatis.annotations.Mapper;
import org.txlcn.demo.common.db.mapper.BaseDemoMapper;

/**
 * Description:
 * Date: 2018/12/25
 *
 * @author ujued
 */
@Mapper
public interface DemoMapper extends BaseDemoMapper {
}
