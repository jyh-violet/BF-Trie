package org.txlcn.demo.servicea;

/**
 * Description:
 * Date: 2018/12/25
 *
 * @author ujued
 */
public interface DemoService {

    String execute(String value, String ex, String flag);
}
