package com.rocketmq.demo.service;

import com.rocketmq.demo.model.Order;

/**
* @author zlt
 */
public interface IOrderService {
    void save(Order order);
}
