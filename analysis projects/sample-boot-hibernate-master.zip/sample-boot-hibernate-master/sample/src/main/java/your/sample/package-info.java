/**
 * アプリケーションルートディレクトリ。
 * <p>Applicationクラスを実行する事でアプリケーションプロセスが立ち上がります。
 */
package your.sample;