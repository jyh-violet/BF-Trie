/**
 * 資産に関連したドメイン列挙型。
 */
package your.sample.model.asset.type;