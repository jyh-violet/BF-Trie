/**
 * 資産に関連したドメイン概念。
 */
package your.sample.model.asset;