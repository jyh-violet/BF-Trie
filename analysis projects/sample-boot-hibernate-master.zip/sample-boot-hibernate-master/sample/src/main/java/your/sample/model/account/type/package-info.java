/**
 * 口座に関連したドメイン列挙型。
 */
package your.sample.model.account.type;