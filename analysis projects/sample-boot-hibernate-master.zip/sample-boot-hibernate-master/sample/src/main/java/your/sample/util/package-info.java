/**
 * 汎用的なユーティリティクラス。
 */
package your.sample.util;