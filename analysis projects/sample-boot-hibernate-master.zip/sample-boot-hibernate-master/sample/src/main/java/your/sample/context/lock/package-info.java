/**
 * ロック関連のインフラ層コンポーネント。
 */
package your.sample.context.lock;