/**
 * 社内管理向けのUI層コンポーネント。
 */
package your.sample.controller.admin;