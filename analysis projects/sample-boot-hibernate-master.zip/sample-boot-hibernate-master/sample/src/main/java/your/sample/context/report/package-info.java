/**
 * 帳票関連のインフラ層コンポーネント。
 */
package your.sample.context.report;