/**
 * 口座に関連したドメイン概念。
 */
package your.sample.model.account;