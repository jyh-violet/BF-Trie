package your.sample.context.mail;

/**
 * メール処理を行います。
 * low: サンプルでは概念クラスだけ提供します。実装はSpringが提供するメールコンポーネントを利用してください。
 */
public class MailHandler {

}
