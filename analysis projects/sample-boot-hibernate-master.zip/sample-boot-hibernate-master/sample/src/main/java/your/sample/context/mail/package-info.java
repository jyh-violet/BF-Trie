/**
 * メール送受信関連のインフラ層コンポーネント。
 */
package your.sample.context.mail;