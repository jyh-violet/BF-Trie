/**
 * 認証/認可関連のインフラ層コンポーネント。
 * <p>Spring Securityをパターン決め打ちで薄くラッピングしています。
 */
package sample.context.security;