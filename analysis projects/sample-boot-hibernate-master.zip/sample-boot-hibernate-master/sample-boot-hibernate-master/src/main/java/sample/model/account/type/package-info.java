/**
 * 口座に関連したドメイン列挙型。
 */
package sample.model.account.type;