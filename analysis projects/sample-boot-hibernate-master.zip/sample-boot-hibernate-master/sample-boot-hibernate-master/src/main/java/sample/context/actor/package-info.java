/**
 * 利用者関連のインフラ層コンポーネント。
 * <p>ユースケース実行時の利用者概念を提供します。
 */
package sample.context.actor;