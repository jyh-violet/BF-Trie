/**
 * ロック関連のインフラ層コンポーネント。
 */
package sample.context.lock;