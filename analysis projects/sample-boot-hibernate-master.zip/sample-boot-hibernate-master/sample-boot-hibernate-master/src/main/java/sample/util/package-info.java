/**
 * 汎用的なユーティリティクラス。
 */
package sample.util;