/**
 * ORM(Object Relational Mapping)関連のインフラ層コンポーネント。
 * <p>主にDB永続化をサポートしています。
 */
package sample.context.orm;