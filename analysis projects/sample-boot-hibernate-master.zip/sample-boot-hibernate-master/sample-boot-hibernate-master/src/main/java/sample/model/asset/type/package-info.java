/**
 * 資産に関連したドメイン列挙型。
 */
package sample.model.asset.type;