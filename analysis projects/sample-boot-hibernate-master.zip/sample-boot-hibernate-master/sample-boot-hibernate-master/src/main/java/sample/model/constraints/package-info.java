/**
 * ドメインで汎用的に利用される制約定義。
 * <p>JSR303(Bean Valildation)の用途で利用される想定です。
 */
package sample.model.constraints;