/**
 * 資産に関連したドメイン概念。
 */
package sample.model.asset;