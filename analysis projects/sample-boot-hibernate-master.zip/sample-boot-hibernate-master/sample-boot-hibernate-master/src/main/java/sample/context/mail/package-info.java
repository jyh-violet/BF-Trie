/**
 * メール送受信関連のインフラ層コンポーネント。
 */
package sample.context.mail;