/**
 * 監査証跡関連のインフラ層コンポーネント。
 * <p>ユースケース実行時の証跡管理をします。
 */
package sample.context.audit;