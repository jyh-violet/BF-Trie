/**
 * システム管理向けのUI層コンポーネント。
 */
package sample.controller.system;