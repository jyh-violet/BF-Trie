/**
 * 帳票関連のインフラ層コンポーネント。
 */
package sample.context.report;