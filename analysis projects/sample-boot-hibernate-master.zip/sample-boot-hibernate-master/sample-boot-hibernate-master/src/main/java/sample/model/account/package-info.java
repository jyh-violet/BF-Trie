/**
 * 口座に関連したドメイン概念。
 */
package sample.model.account;