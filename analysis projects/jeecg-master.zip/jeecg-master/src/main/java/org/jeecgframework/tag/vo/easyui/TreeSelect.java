package org.jeecgframework.tag.vo.easyui;
import java.io.Writer;
import javax.servlet.jsp.tagext.TagSupport;


public class TreeSelect extends TagSupport {
	/*protected String value; 
	protected String id; 
	protected String pid; 
	protected String name;  
	protected String text; 
	protected String width; ֵ
 
	public void setWidth(String width) {
		this.width = width;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setText(String text) {
		this.text = text;
	}

	public void setValue(String value) {
		this.value = value;
	}

 
*/
	 
	public String end(Writer writer, String body) {
		StringBuffer sb = new StringBuffer();
	
		return sb.toString();
	}
}
