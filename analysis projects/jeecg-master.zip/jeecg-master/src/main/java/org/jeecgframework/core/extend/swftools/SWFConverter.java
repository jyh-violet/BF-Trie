package org.jeecgframework.core.extend.swftools;

public interface SWFConverter {
	public void convert2SWF(String inputFile,String swfFile,String extend);
	public void convert2SWF(String inputFile,String extend);
}
