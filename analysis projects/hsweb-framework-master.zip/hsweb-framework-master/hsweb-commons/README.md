# 通用功能模块
实现通用CRUD功能,增删改查,直接继承之.
# 目录介绍
1. [hsweb-commons-controller](hsweb-commons-controller):通用springmvc控制器
1. [hsweb-commons-dao](hsweb-commons-dao):通用dao实现
1. [hsweb-commons-entity](hsweb-commons-entity):通用实体类
1. [hsweb-commons-service](hsweb-commons-service):通用服务类
1. [hsweb-commons-utils](hsweb-commons-utils):工具类

# 使用
[如何建一个增删改查功能](create-crud.md)