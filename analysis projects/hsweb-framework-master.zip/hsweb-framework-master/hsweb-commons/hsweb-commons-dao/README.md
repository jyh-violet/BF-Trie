# 通用DAO实现

支持动态条件的通用CRUD实现

⚠️注意:目前仅提供了[mybatis](hsweb-commons-dao-mybatis)实现.
