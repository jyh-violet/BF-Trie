package org.hswebframework.web.dao.crud;

import lombok.Data;

/**
 *
 * @author zhouhao
 * @since
 */
@Data
public class NestEntity {
    private String name;
}
