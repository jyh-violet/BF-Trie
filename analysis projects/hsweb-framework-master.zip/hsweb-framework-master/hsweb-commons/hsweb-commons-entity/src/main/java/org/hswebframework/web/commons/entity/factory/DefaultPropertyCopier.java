package org.hswebframework.web.commons.entity.factory;

/**
 * 默认的属性复制器
 *
 * @author zhouhao
 */
@FunctionalInterface
public interface DefaultPropertyCopier extends PropertyCopier<Object, Object> {
}
