package org.hswebframework.web.authorization.oauth2.client.exception;

/**
 *
 * @author zhouhao
 * @since 3.0
 */
public class UnCheckException extends RuntimeException {
    public UnCheckException(Throwable cause) {
        super(cause);
    }
}
