# oauth2 认证模块

# 模块说明
| 模块       | 说明          |   进度 |
| ------------- |:-------------:| ----|
|[hsweb-authorization-oauth2-client](hsweb-authorization-oauth2-client)|OAuth2 客户端API| 90%|
|[hsweb-authorization-oauth2-server](hsweb-authorization-oauth2-server)|OAuth2 服务端API| 90%|