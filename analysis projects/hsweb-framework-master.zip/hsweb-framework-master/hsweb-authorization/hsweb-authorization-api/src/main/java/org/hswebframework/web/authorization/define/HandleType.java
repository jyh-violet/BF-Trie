package org.hswebframework.web.authorization.define;

public enum HandleType{
        RBAC,DATA
    }