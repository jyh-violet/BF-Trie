package org.hswebframework.web.authorization.define;

public enum Phased {
    before, after
}