package org.hswebframework.web.authorization;

import java.io.Serializable;

/**
 * @author zhouhao
 * @since 3.0.0-RC
 */
public interface AuthenticationRequest extends Serializable {
}
