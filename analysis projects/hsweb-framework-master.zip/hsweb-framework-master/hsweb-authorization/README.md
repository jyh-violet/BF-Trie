# 授权认证模块
用于整个系统的授权认证管理

# 目录介绍
1. [hsweb-authorization-api](hsweb-authorization-api):权限控制API
2. [hsweb-authorization-oauth2](hsweb-authorization-oauth2):oauth2支持
3. [hsweb-authorization-basic](hsweb-authorization-basic):权限控制基础实现
4. [hsweb-authorization-jwt](hsweb-authorization-jwt):权限控制jwt拓展

