package com.perye.dokit.dto;

import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

/**
 * @author perye
 * @email peryedev@gmail.com
 * @date 2019/12/11
 */
@Getter
@Setter
public class DictSmallDto implements Serializable {

    private Long id;
}
