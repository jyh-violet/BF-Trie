package com.perye.dokit.query;

import lombok.Data;
import java.util.List;
import com.perye.dokit.annotation.Query;

@Data
public class CaptchaQueryCriteria{
}
