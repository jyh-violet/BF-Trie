package com.perye.dokit.aspect;

/**
 * 限流枚举
 */
public enum LimitType {
    // 默认
    CUSTOMER,
    //  by ip addr
    IP;
}
