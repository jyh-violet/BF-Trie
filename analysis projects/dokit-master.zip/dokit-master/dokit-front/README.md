# dokit-front

#### Build Setup
``` bash
# 安装依赖
npm install
or
yarn install

# 启动服务 localhost:8000
npm run dev
or
yarn run dev

# 构建生产环境
npm run build
or
yarn run build
```