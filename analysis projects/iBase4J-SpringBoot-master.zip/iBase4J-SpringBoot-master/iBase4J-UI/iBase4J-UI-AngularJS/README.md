[iBase4J](http://git.oschina.net/iBase4J/iBase4J)
==

请下载nginx，反向代理静态页面

测试帐号：admin/111111

![QQ群](http://pub.idqqimg.com/wpa/images/group.png "QQ群")

![QQ群](http://git.oschina.net/iBase4J/iBase4J/raw/master/img/1464169485871.png "QQ群")
