#iBase4J-UI-AdminLTE 版本UI

#基本功能齐全，价格面议。有需要请与我联系！QQ：2296277393

#主要技术：jquery, bootstrap, AdminLTE, treetable, ztree, Select2, switchery, formautofill 等等

#预览
![登录](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/1.png "登录")
![主页](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/2.png "主页")
![预览](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/3.png "预览")
![预览](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/4.png "预览")
![预览](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/5.png "预览")
![预览](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/6.png "预览")
![预览](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/7.png "预览")
![预览](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/8.png "预览")
![预览](https://gitee.com/iBase4J/iBase4J-SpringBoot/raw/master/iBase4J-UI/iBase4J-UI-AdminLTE/desc/9.png "预览")