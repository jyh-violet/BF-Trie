#iBase4J-UI-DataTables 版本UI，价格面议。有需要请与作者联系！QQ：2296277393
主要技术：vue, dataTables, jquery, bootstrap, jquery-treetable, ztree, Select2, switchery, jquery.formautofill 等等


![新版](http://git.oschina.net/iBase4J/iBase4J/raw/master/img/2D7O7AOE9DS.png "新版")
![新版](http://git.oschina.net/iBase4J/iBase4J/raw/master/img/65R6377JCQS0VFHX3.png "新版")
![新版](http://git.oschina.net/iBase4J/iBase4J/raw/master/img/7HNWRCKCLCU66G8.png "新版")