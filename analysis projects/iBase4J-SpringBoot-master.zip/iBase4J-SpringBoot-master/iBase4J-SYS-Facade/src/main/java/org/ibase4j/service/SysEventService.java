package org.ibase4j.service;

import top.ibase4j.core.base.BaseService;
import top.ibase4j.model.SysEvent;

/**
 * @author ShenHuaJie
 * @since 2018年4月24日 上午10:59:04
 */
public interface SysEventService extends BaseService<SysEvent> {

}
