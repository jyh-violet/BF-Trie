package org.ibase4j.mapper;

import org.ibase4j.model.SysDept;

import top.ibase4j.core.base.BaseMapper;

/**
 * @author ShenHuaJie
 * @since 2018年3月3日 下午7:22:33
 */
public interface SysDeptMapper extends BaseMapper<SysDept> {

}