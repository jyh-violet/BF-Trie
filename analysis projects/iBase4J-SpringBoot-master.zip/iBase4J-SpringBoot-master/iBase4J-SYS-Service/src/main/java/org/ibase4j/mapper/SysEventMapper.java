package org.ibase4j.mapper;

import top.ibase4j.core.base.BaseMapper;
import top.ibase4j.model.SysEvent;

public interface SysEventMapper extends BaseMapper<SysEvent> {
}