package com.quark.admin.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by lhr on 17-7-31.
 */
@Configuration
@ComponentScan(basePackages = "com.quark.common")
public class AdminConfig {
}
