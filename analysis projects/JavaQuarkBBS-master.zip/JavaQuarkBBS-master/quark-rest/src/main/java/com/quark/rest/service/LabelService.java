package com.quark.rest.service;

import com.quark.common.base.BaseService;
import com.quark.common.entity.Label;

/**
 * @Author LHR
 * Create By 2017/8/27
 */
public interface LabelService extends BaseService<Label>{
}
