package com.quark.common.utils;

/**
 * @Author LHR
 * Create By 2017/8/19
 */
public class Constants {

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
