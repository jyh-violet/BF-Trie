package com.stylefeng.guns.core;

/**
 * 此类用来获取core模块的包路径
 *
 * @author fengshuonan
 * @Date 2017/12/5 下午12:44
 */
public class CoreFlag {

}