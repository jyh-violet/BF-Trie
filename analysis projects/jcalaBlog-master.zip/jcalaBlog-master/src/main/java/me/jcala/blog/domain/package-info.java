/**
 * javaBean实体类所在的包
 *
 * 包下的实体大都使用了lombok工具包进行生成getter,setter,constructor等
 *
 * 如果IDE报错，请安装elipse或者idea的lombok插件
 */
package me.jcala.blog.domain;