/**
 * service具体实现类
 *
 *包下的类全都实现于inter包下的接口
 *
 *具体实现方法部分使用了事务处理，和ehcache缓存
 */
package me.jcala.blog.service;