package me.jcala.blog.utils;

import org.junit.Test;

/**
 * Created by Administrator on 2016/9/3.
 */
public class ToolsTest {
    @Test
    public void testGetTagList(){
        System.out.println(System.getProperty("user.dir"));
    }
}
