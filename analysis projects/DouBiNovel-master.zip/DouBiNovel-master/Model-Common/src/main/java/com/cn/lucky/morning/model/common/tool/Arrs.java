package com.cn.lucky.morning.model.common.tool;

public class Arrs {

    public static String[] strs(String... str) {
        return str;
    }

}
