package cn.exrick.xboot.common.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author Exrickx
 */
@Data
@AllArgsConstructor
public class IpInfo {

    String url;

    String p;
}
