package cn.exrick.xboot.generator.bean;

import lombok.Data;

/**
 * @author exrick
 */
@Data
public class Item {

    private String type;

    private String lowerName;

    private String upperName;

    private String lineName;

    private String title;
}
