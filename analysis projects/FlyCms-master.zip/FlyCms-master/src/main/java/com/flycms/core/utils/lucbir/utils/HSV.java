package com.flycms.core.utils.lucbir.utils;

/**
 * Created by VenyoWang on 2016/7/8.
 */
public class HSV {
    /** 0-360 */
    public int h;
    /** 0-255 */
    public int s;
    /** 0-255 */
    public int v;
}
