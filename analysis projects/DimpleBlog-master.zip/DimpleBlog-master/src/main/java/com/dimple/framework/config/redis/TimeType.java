package com.dimple.framework.config.redis;

/**
 * @className: TimeType
 * @description:
 * @author: Dimple
 * @date: 2020/1/1
 */
public enum TimeType {
    SECONDS,
    MINUTES,
    HOURS,
    DAY,
}
