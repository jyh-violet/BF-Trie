package com.dimple.project.monitor.service;

import java.util.Map;

/**
 * <p>
 * description
 * </p>
 *
 * @author Dimple
 * @date 06/04/20 16:51
 */
public interface ServerService {

    Map<String, Object> getServers();
}
