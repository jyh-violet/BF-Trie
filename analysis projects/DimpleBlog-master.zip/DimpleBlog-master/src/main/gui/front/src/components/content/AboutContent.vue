<template>
    <div class="article-content layout-content">
        <Row>
            <Col :xs="24" :sm="24" :md="24" :lg="24" :xl="17">
                <div class="layout-left">
                    <div class="about-content" style="padding:0;">
                        <ul class="myblog">
                            <div class="intro">
                                <h5>博客简介 | Blog：</h5>
                                <div class="intro_detail">
                                    <div>
                                        程&nbsp;序：基于SpringBoot开发的个人博客程序。 <span class="wb_url"><a
                                            href="https://github.com/DimpleFeng/DimpleBlog"
                                            target="_blank">GitHub</a></span><br>
                                        域&nbsp;名：www.bianxiaofeng.com，创建于2017<span class="wb_url"><a
                                            href="https://wanwang.aliyun.com/"
                                            target="_blank">注册域名</a></span><br>
                                        服务器：阿里云轻量级应用服务器(2G)<span class="wb_url"><a
                                            href="https://promotion.aliyun.com/ntms/yunparter/invite.html?userCode=3viaxu0k"
                                            target="_blank">购买空间</a></span><br>
                                        备案号：蜀ICP备 19004343<br>
                                    </div>
                                </div>
                                <h5>搭建博客目的 | Goal：</h5>
                                <div class="intro_detail">
                                    <div>
                                        &nbsp;&nbsp;&nbsp;&nbsp;计算机、互联网这一类的东西，很多很庞杂，要想全部记住是不可能的事。所以在上大学不久，我就使用为知笔记、有道云或者OneNote这些笔记工具记录自己的笔记，方便自己什么时候遗忘了，再拿起来看看，
                                        这是最开始的目的。随着接触互联网的东西越来越多，分享这个词在我的身边越来越多的被提及，CSDN、博客园等等博客网站出现在我的眼前，我开始觉得，自己写的东西，如果能够实实在在的帮助到别人，
                                        那才是我记录的意义。所以我一边在自己的小本本上记录，一边开始注册博客网站的账号，开始在网络上写博客。
                                        <hr>
                                        &nbsp;&nbsp; &nbsp;&nbsp;为什么开始做自己的网站，我记得有一天很晚了，我发现网络上关于某一块的知识很少，并不全面，我从下午一直写到了晚上，废寝忘食，晚上十点左右，我写完了，将博客发出去的时候，心里参数一口气。
                                        于是我开始把博客链接分享给别人，以为会对别人有帮助，结果发现404，我那时才知道原来CSDN的博客，竟然是要审核的，与此同时，CSDN网站的广告越来越多。
                                        <hr>
                                        &nbsp;&nbsp;&nbsp;&nbsp;于是我开始做自己的网站，当时好像才大二吧，我啥都不会，看着很多大神的个人博客网站花里胡哨，心有余而力不足。偶然间发现了HEXO这个静态博客，于是开始各种设计，各种DIY。在使用了快一年后，我发现了
                                        它的问题，由于是静态博客，编辑很不方便，需要自己在本地编辑，然后上传，由于是静态服务器托管在GitHub或者Coding，访问速度可想而知。于是有了您现在所看到的。
                                        <hr>
                                        &nbsp;&nbsp;&nbsp;&nbsp;我不认为个人博客网站需要多漂亮美丽，“内涵”很重要，如果装饰的很花哨，而内容平平一般，我觉得博客分享的意义便不复存在。
                                    </div>
                                </div>
                            </div>
                        </ul>
                        <span class="ly_button"><a href="/leaveComment" target="_blank">留言</a></span>
                        <p class="ab_dubai">
                        <div class="intro">
                            <h5>个人简介 | Resume：</h5>
                            <div class="intro_detail">
                                <div>
                                    人物：Dimple<br>
                                    性别：男<br>
                                    年龄：96后<br>
                                    身高：&lt; 2m<br>
                                    体重：&gt; 65kg<br>
                                    现居：中国·四川·成都<br>
                                    职业：Java开发工程师<br>
                                    <span>注意：此处捡一些比较重要的说。</span><br>
                                    1、2015年9月—2019年6月开始并结束了我的大学生活，大学无挂科，无违纪，大学里连续三年专业综测第一获国家励志奖学金。<br>
                                    2、获成都市龙泉驿区成龙谷创业奖金10000元。<br>
                                    3、做过项目负责人，大一到大三带过三个项目。 <span class="wb_url"><a href="#project">详情</a></span></a><br>
                                    4、做过学生工作，班长，学生会部长，班主任助理啥都干。<br>
                                    5、2017年9月大三上进入中国中铁二院实习，担任项目经理助理。2018年6月进入一家民营企业实习，担任Java开发工程师。2018年10月至今，进入一家外企实习，次年6月转正,担任Java开发工程师。<br>
                                </div>
                            </div>
                            <h5>编程理想 | Dream：</h5>
                            <div class="intro_detail">
                                <div>
                                    我希望我自己是一个会技术的产品经理，会产品的工程师。写代码不能不带业务胡乱写，而做产品不能不考虑实际的胡乱设计，我想融合产品经理与开发，做一个融合的人。
                                </div>
                            </div>
                            <h5>技术方向 | Technology：</h5>
                            <div class="intro_detail">
                                <div>
                                    1、掌握Java基础语法及面向对象设计，数据结构。<br>
                                    2、熟悉HTML、CSS、Javascript(搬砖型)、AJAX、JSON等Web页面技术。<br>
                                    3、熟悉主流JavaEE开发技术，熟练使用Struts2，Hibernate，Spring，Mybatis，Shiro，SpringBoot等。<br>
                                    4、精通MySQL数据库，能熟练地运用SQL语句。<br>
                                    5、熟悉Redis等NOSQL数据库。<br>
                                    6、熟悉Git，Maven等工具。<br>
                                    7、会使用SVN、Git版本控制工具。<br>
                                    8、有良好的代码编写习惯，熟悉开发/使用文档的编写。<br>
                                    9、其他技术正在学习中！唯一能持久的竞争优势是胜过竞争对手的学习能力。<br>
                                </div>
                            </div>
                            <h5 id="project">项目经验 | Project：</h5>
                            <div class="intro_detail">
                                <div>
                                    <span>注意：该处只介绍项目名称、运行环境、（不包含在公司做的任何项目）...</span><br>
                                    1、个人博客系统（正如您所看到的）。<br>
                                    2、《来影，一款基于AR与3D的旅游软件》（pc端·主移动端·我带的）。 <span class="wb_url"><a
                                        href="https://www.iqiyi.com/w_19rwhwxmw1.html">详情</a></span></a><br>
                                    3、《基于无线传感器网的物联网智慧农业系统》（pc端·我带的）。 <span class="wb_url"><a
                                        href="https://www.iqiyi.com/w_19rwhxeq81.html">详情</a></span></a><br>
                                    4、《LED光源型植物工厂植物生产状况监测算法研究》（大一刚入学就接手的老师的项目，作为负责人的我纯打酱油）。<br/>
                                    4、《在线考试系统》（pc端）。<br>
                                    5、其他(遗忘，是对过去的缅怀)。<br>
                                </div>
                            </div>
                            <h5>兴趣爱好 | Hobby：</h5>
                            <div class="intro_detail">
                                <div>
                                    1、拿到软件会胡思乱想其背后在干些什么，比如搜索的时候各种条件是怎么组合的，代码是什么。<br>
                                    2、喜欢电子竞技（LOL），现在的游戏不是以前的游戏，锻炼人反应和临场发挥能力，预防痴呆(真的)，但我真的很菜。<br>
                                    3、喜欢旅游，趁着还有学生证的时光去了些地方，接下来有Time和Money的时候，还要去开拓下眼界。<br>
                                    4、喜欢读书，照着书中示例专门敲错，然后去解决问题。<br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Col>
            <Col :xs="24" :sm="24" :md="24" :lg="24" :xl="7">
                <div class="layout-right">
                    <Recommend/>
                    <Hot style="margin-top:15px;"/>
                    <TagWall style="margin-top:15px;"/>
                    <FriendLinks style="margin-top:15px;"/>
                </div>
            </Col>
        </Row>
    </div>
</template>

<script>
    import Recommend from "../../views/Recommend";
    import TagWall from "../../views/TagWall";
    import Hot from "../../views/Hot";
    import FriendLinks from "../../views/FriendLinks";

    export default {
        name: "AboutContent",
        components: {
            Recommend, TagWall, Hot, FriendLinks
        },
    }
</script>

<style lang="stylus" type="text/stylus" rel="stylesheet/stylus">
    @import "../../common/stylus/theme.styl";

    .about-content {
        line-height: 25px;
        margin-bottom: 30px;
        padding: 20px;
    }

    .intro {
        float: left;
        font-size: 14px;
    }

    .intro h5 {
        width: 60%;
        font-weight: bold;
        margin-top: 10px;
        float: left;
    }

    .intro hr {
        border: 0.5px dashed #ccc;
    }

    .intro_detail div {
        margin: 10px 0;
        float: left;
        padding: 10px 20px 10px 20px;
        color: #555;
        border-left: 4px solid #0cc;
    }

    .intro_detail .wb_url {
        margin: 0 10px;
    }

    .intro_detail .wb_url a {
        color: #1CA368;
    }

    .intro span {
        color: #ff3366;
    }

    .ab_box h3 {
        margin: 10px 0 10px;
        font-size: 18px;
    }

    .ab_box p {
        color: #666;
        margin-bottom: 5px
    }

    .avatar_pic img {
        width: 100%;
        border-radius: 50%;
    }

    .ab_dubai {
        margin-bottom: 15px;
        display: inline-block;
    }

    .ly_button {
        float: right;
        width: 100px;
        background: #000;
        text-align: center;
        border-radius: 3px;
        line-height: 30px
    }

    .ly_button a {
        color: #FFF
    }

</style>
