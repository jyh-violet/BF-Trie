INSERT INTO `dimpleblog-vue`.sys_user_role (user_id, role_id) VALUES (1, 1);
INSERT INTO `dimpleblog-vue`.sys_user_role (user_id, role_id) VALUES (2, 2);