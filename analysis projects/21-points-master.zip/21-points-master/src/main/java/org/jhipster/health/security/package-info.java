/**
 * Spring Security configuration.
 */
package org.jhipster.health.security;
