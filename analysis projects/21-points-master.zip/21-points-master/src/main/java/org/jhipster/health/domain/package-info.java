/**
 * JPA domain objects.
 */
package org.jhipster.health.domain;
