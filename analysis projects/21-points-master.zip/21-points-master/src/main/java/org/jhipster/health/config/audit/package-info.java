/**
 * Audit specific code.
 */
package org.jhipster.health.config.audit;
