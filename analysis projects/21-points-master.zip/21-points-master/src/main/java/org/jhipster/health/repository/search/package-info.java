/**
 * Spring Data Elasticsearch repositories.
 */
package org.jhipster.health.repository.search;
