/**
 * Service layer beans.
 */
package org.jhipster.health.service;
