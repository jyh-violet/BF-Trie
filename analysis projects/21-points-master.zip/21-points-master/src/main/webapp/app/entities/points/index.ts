export * from './points.service';
export * from './points-update.component';
export * from './points-delete-dialog.component';
export * from './points-detail.component';
export * from './points.component';
export * from './points.route';
