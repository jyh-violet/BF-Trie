export * from './preferences.service';
export * from './preferences-update.component';
export * from './preferences-delete-dialog.component';
export * from './preferences-detail.component';
export * from './preferences.component';
export * from './preferences.route';
