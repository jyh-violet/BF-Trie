export * from './weight.service';
export * from './weight-update.component';
export * from './weight-delete-dialog.component';
export * from './weight-detail.component';
export * from './weight.component';
export * from './weight.route';
