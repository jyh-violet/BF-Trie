<!--
如果你不认真勾选下面的内容，我可能会直接关闭你的 Issue。
提问之前，建议先阅读 https://github.com/ruby-china/How-To-Ask-Questions-The-Smart-Way
-->

**我确定我已经查看了** (标注`[ ]`为`[x]`)

- [ ] [Halo 使用文档](https://docs.halo.run/)
- [ ] [Github Wiki 常见问题](https://github.com/ruibaby/halo/wiki/4.-%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98)
- [ ] [其他 Issues](https://github.com/ruibaby/halo/issues)

----

**我要申请**  (标注`[ ]`为`[x]`)

- [ ] BUG 反馈
- [ ] 添加新的特性或者功能
- [ ] 请求技术支持