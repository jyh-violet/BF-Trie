package com.raysmond.blog.support.web;

/**
 * @author Raysmond
 */
public interface SyntaxHighlightService {
    String highlight(String content);
}
