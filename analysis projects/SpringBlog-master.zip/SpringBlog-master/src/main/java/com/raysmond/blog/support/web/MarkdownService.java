package com.raysmond.blog.support.web;

/**
 * @author Raysmond
 */
public interface MarkdownService {
    String renderToHtml(String content);
}
