

package cn.ffast.web.service.impl.sys;

import cn.ffast.core.support.CrudServiceImpl;

import cn.ffast.web.dao.sys.ScheduleJobLogMapper;

import cn.ffast.web.entity.sys.ScheduleJobLog;
import cn.ffast.web.service.sys.ScheduleJobLogService;

import org.springframework.stereotype.Service;


@Service
public class ScheduleJobLogServiceImpl extends CrudServiceImpl<ScheduleJobLogMapper, ScheduleJobLog, Long> implements ScheduleJobLogService {



}
