package cn.ffast.web.dao.sys;

import cn.ffast.web.entity.sys.ScheduleJob;
import com.baomidou.mybatisplus.mapper.BaseMapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * @description: 定时任务
 * @copyright:
 * @createTime: 2017年08月31日 09:49:42
 * @author: dzy
 * @version: 1.0
 */

public interface ScheduleJobMapper extends BaseMapper<ScheduleJob> {
	

}
