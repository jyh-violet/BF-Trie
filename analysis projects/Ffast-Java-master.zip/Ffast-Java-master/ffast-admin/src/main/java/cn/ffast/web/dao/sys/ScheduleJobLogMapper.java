package cn.ffast.web.dao.sys;

import cn.ffast.web.entity.sys.ScheduleJobLog;
import com.baomidou.mybatisplus.mapper.BaseMapper;

import org.apache.ibatis.annotations.Mapper;

/**
 * @description: 定时任务日志
 * @copyright:
 * @createTime: 2017年08月31日 09:49:42
 * @author: dzy
 * @version: 1.0
 */
public interface ScheduleJobLogMapper extends BaseMapper<ScheduleJobLog> {
	
}
