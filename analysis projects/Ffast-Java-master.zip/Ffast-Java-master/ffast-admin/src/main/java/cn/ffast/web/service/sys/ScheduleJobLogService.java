package cn.ffast.web.service.sys;

import cn.ffast.core.support.ICrudService;
import cn.ffast.web.entity.sys.ScheduleJobLog;


import java.util.Map;
/**
 * @description: 定时任务日志Service
 * @copyright:
 * @createTime: 2018/6/29 15:23
 * @author：dzy
 * @version：1.0
 */
public interface ScheduleJobLogService extends ICrudService<ScheduleJobLog,Long> {


	
}
