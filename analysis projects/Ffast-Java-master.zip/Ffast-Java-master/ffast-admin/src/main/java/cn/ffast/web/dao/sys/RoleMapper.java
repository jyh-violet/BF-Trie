package cn.ffast.web.dao.sys;

import cn.ffast.web.entity.sys.Role;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * @description: 系统_角色Mapper接口
 * @copyright:
 * @createTime: 2017年08月31日 09:49:42
 * @author: dzy
 * @version: 1.0
 */
public interface RoleMapper extends BaseMapper<Role> {

}