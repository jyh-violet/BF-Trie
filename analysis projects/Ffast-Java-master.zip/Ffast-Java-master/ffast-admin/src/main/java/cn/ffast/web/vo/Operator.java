package cn.ffast.web.vo;

import cn.ffast.core.auth.OperatorBase;

public class Operator extends OperatorBase {
    private Long sortId;

    public Long getSortId() {
        return sortId;
    }

    public void setSortId(Long sortId) {
        this.sortId = sortId;
    }


}
